﻿using DataAccess;
using DataAccess.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExpenseTrackerBE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly Context _context;

        public TransactionController(Context context)
        {
            _context = context;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var transactions = await _context.Transactions.ToListAsync();
                return Ok(transactions);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        [HttpPost("Upsert")]
        public async Task<IActionResult> Upsert(Transaction transaction)
        {
            try
            {
                if (transaction.Id > 0)
                {
                    var existingTransaction = await _context.Transactions.FindAsync(transaction.Id);
                    if (existingTransaction == null)
                        return NotFound("Transaction not found.");

                    existingTransaction.Date = transaction.Date;
                    existingTransaction.Description = transaction.Description;
                    existingTransaction.Amount = transaction.Amount;
                    existingTransaction.Type = transaction.Type;
                }
                else
                {
                    _context.Transactions.Add(transaction);
                }

                await _context.SaveChangesAsync();
                return Ok(transaction);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
