import { Component } from '@angular/core';
import { MaterialModule } from '../material/material.module';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'side-nav',
  standalone: true,
  imports: [MaterialModule, RouterModule],
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss'],
})
export class SideNavComponent {
  navItems: { name: string; link: string }[] = [
    { name: 'Maintenance', link: 'maintenance' },
    { name: 'View Data', link: 'view' },
  ];

  /**
   * TrackBy function to uniquely identify items in *ngFor
   * @param index - Index of the current item
   * @param item - The item object
   * @returns The unique identifier for the item
   */
  trackByFn(index: number, item: { name: string; link: string }): string {
    return item.name; // Use the `name` property as the unique key
  }
}
