import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApiService } from '../api.service';
import { MaterialModule } from '../material/material.module'; // Ensure correct path

export interface Transaction {
  id: number;
  date: Date;
  description: string;
  amount: number;
  type: string;
  createdOn: Date;
}

@Component({
  selector: 'maintenance',
  standalone: true, // Ensures the component is standalone
  imports: [MaterialModule, ReactiveFormsModule], // Include ReactiveFormsModule
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.scss'],
})
export class MaintenanceComponent implements OnInit {
  // Arrays for year and month selections
  years: number[] = [];
  months: { index: number; name: string }[] = [];

  // Reactive FormGroup
  transactionForm!: FormGroup;

  // Data source for Material Table
  dataSource = new MatTableDataSource<Transaction>();
  columns = [
    'id',
    'date',
    'description',
    'amount',
    'type',
    'createdOn',
    'actions',
  ];

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private apiService: ApiService
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.fetchTransactions();
    this.initializeYearsAndMonths();
  }

  /**
   * Initializes the Reactive Form
   */
  private initializeForm(): void {
    this.transactionForm = this.fb.group(
      {
        id: [0],
        year: [new Date().getFullYear(), [Validators.required]],
        month: [new Date().getMonth(), [Validators.required]],
        date: [null, [Validators.required]],
        description: ['', [Validators.required]],
        amount: [null, [Validators.required, Validators.min(0.01)]],
        type: ['DEBIT', [Validators.required]],
      },
      { validators: [this.dateValidator.bind(this)] } // Bind 'this' to the validator
    );
  }

  /**
   * Fetches all transactions from the backend API
   */
  private fetchTransactions(): void {
    this.apiService.getAllTransactions().subscribe({
      next: (res: Transaction[]) => {
        this.dataSource.data = res;
      },
      error: (err) => {
        console.error('Error fetching transactions', err);
        this.snackBar.open('Failed to load transactions', 'Close', {
          duration: 3000,
        });
      },
    });
  }

  /**
   * Initializes the years and months arrays for selection
   */
  private initializeYearsAndMonths(): void {
    const currentYear = new Date().getFullYear();
    for (let year = currentYear; year >= 2021; year--) {
      this.years.push(year);
    }

    this.months = [
      { index: 0, name: 'January' },
      { index: 1, name: 'February' },
      { index: 2, name: 'March' },
      { index: 3, name: 'April' },
      { index: 4, name: 'May' },
      { index: 5, name: 'June' },
      { index: 6, name: 'July' },
      { index: 7, name: 'August' },
      { index: 8, name: 'September' },
      { index: 9, name: 'October' },
      { index: 10, name: 'November' },
      { index: 11, name: 'December' },
    ];
  }

  /**
   * Custom Validator to ensure the date is valid for the selected month
   */
  private dateValidator(group: AbstractControl): { [key: string]: any } | null {
    const date = group.get('date')?.value;
    const month = group.get('month')?.value;
    const year = group.get('year')?.value;

    if (date === null || month === null || year === null) {
      return { invalidDate: true };
    }

    const validDays = [
      31,
      this.isLeapYear(year) ? 29 : 28,
      31,
      30,
      31,
      30,
      31,
      31,
      30,
      31,
      30,
      31,
    ];

    if (date > 0 && date <= validDays[month]) {
      return null;
    } else {
      return { invalidDate: true };
    }
  }

  /**
   * Helper method to determine if a year is a leap year
   */
  private isLeapYear(year: number): boolean {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  }

  /**
   * Inserts or updates a transaction based on the form data
   */
  insertForm(): void {
    if (this.transactionForm.invalid) {
      this.snackBar.open('Please correct the errors in the form', 'Close', {
        duration: 3000,
      });
      return;
    }

    const formValues = this.transactionForm.value;

    const transaction: Transaction = {
      id: formValues.id,
      date: new Date(formValues.year, formValues.month, formValues.date),
      description: formValues.description,
      amount: formValues.amount,
      type: formValues.type,
      createdOn: new Date(),
    };

    this.apiService.upsertTransaction(transaction).subscribe({
      next: (res: Transaction) => {
        this.snackBar.open('Transaction saved successfully!', 'OK', {
          duration: 3000,
        });

        // Reset the form to default values
        this.transactionForm.reset({
          id: 0,
          year: new Date().getFullYear(),
          month: new Date().getMonth(),
          type: 'DEBIT',
        });

        // Update the data source
        const index = this.dataSource.data.findIndex((t) => t.id === res.id);
        if (index !== -1) {
          // Update existing transaction
          this.dataSource.data[index] = res;
        } else {
          // Add new transaction
          this.dataSource.data = [res, ...this.dataSource.data];
        }
        this.dataSource._updateChangeSubscription(); // Refresh the table
      },
      error: (err) => {
        console.error('Error saving transaction', err);
        this.snackBar.open('Failed to save transaction', 'Close', {
          duration: 3000,
        });
      },
    });
  }

  /**
   * Populates the form with the selected transaction's data for editing
   */
  edit(transactionToEdit: Transaction): void {
    this.transactionForm.setValue({
      id: transactionToEdit.id,
      year: new Date(transactionToEdit.date).getFullYear(),
      month: new Date(transactionToEdit.date).getMonth(),
      date: new Date(transactionToEdit.date).getDate(),
      description: transactionToEdit.description,
      amount: transactionToEdit.amount,
      type: transactionToEdit.type,
    });
  }

  /**
   * Deletes a transaction after user confirmation
   */
  deleteElement(transaction: Transaction): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Delete Confirmation',
        message: 'This will delete the transaction. Are you sure?',
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.apiService.deleteTransaction(transaction.id).subscribe({
          next: (res: string) => {
            if (res === 'deleted') {
              this.dataSource.data = this.dataSource.data.filter(
                (v) => v.id !== transaction.id
              );
              this.snackBar.open('Transaction deleted successfully!', 'OK', {
                duration: 3000,
              });
              this.dataSource._updateChangeSubscription(); // Refresh the table
            } else {
              this.snackBar.open('Failed to delete transaction', 'Close', {
                duration: 3000,
              });
            }
          },
          error: (err) => {
            console.error('Error deleting transaction', err);
            this.snackBar.open('Error deleting transaction', 'Close', {
              duration: 3000,
            });
          },
        });
      }
    });
  }

  //#region Form Control Getters
  get IdControl(): AbstractControl {
    return this.transactionForm.get('id') as AbstractControl;
  }

  get YearControl(): AbstractControl {
    return this.transactionForm.get('year') as AbstractControl;
  }

  get MonthControl(): AbstractControl {
    return this.transactionForm.get('month') as AbstractControl;
  }

  get DateControl(): AbstractControl {
    return this.transactionForm.get('date') as AbstractControl;
  }

  get DescriptionControl(): AbstractControl {
    return this.transactionForm.get('description') as AbstractControl;
  }

  get AmountControl(): AbstractControl {
    return this.transactionForm.get('amount') as AbstractControl;
  }

  get TxTypeControl(): AbstractControl {
    return this.transactionForm.get('type') as AbstractControl;
  }
  //#endregion
}
